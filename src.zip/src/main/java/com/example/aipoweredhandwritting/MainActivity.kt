package com.example.aipoweredhandwritting


import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import net.objecthunter.exp4j.ExpressionBuilder
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var cameraButton: Button
    private lateinit var textResult: TextView
    private lateinit var imageUri: Uri
    private lateinit var solveBtn:Button
    private lateinit var convertBtn:Button
     var equationClicked:Boolean = false


    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) launchCamera()
        else Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
    }

    private val takePictureLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                imageView.setImageURI(imageUri)
                solveBtn.setOnClickListener(){
                    equationClicked=true
                processImageWithAI(imageUri)}
                convertBtn.setOnClickListener(){
                    processImageWithAI(imageUri)
                }
            } else {
                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        cameraButton = findViewById(R.id.btnCamera)
        textResult = findViewById(R.id.textResult)
        solveBtn=findViewById(R.id.btnEquation)
        convertBtn=findViewById(R.id.btnConvert)

        cameraButton.setOnClickListener {
            checkCameraPermission()
        }

    }

    private fun checkCameraPermission() {
        when {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED -> launchCamera()
            else -> requestPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun launchCamera() {
        try {
            val imageFile = File.createTempFile("IMG_", ".jpg", externalCacheDir ?: cacheDir)
                .apply { createNewFile() }

            imageUri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                imageFile
            )
            takePictureLauncher.launch(imageUri)
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun processImageWithAI(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val image = InputImage.fromBitmap(bitmap, 0)

            // 👇 Correct client creation
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val blocks = visionText.textBlocks
                    var fullText = ""
                    for (block in blocks) {
                        fullText += block.text + "\n"
                    }
                    if(equationClicked==true) {
                        val solution = solveMath(fullText)
                        textResult.text = "Detected:\n$fullText\nSolved: $solution"
                    }
                    else {
                        textResult.text = "Detected:\n$fullText"
                    }
                }

                .addOnFailureListener { e ->
                    textResult.text = "Failed to recognize text: ${e.localizedMessage}"
                }

        } catch (e: Exception) {
            textResult.text = "Error reading image: ${e.localizedMessage}"
        }
    }


    private fun solveMath(expression: String): String {
        return try {
            val cleanedExpr = expression.replace("[^0-9+\\-*/().]", "")
            if (cleanedExpr.isBlank()) {
                return "Could not solve: no math expression found"
            }
            val expr = ExpressionBuilder(cleanedExpr).build()
            val result = expr.evaluate()
            result.toString()
        } catch (e: Exception) {
            "Could not solve: ${e.message}"
        }
    }

}
